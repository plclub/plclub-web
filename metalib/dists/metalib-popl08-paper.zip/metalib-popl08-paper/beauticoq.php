<?php

//----------------------------------------------------------------------------

// For security reasons: prevent from reading of all directories
define('BEAUTICOQ_WEB_ROOT_DIRECTORY', '');

// Put 'false' to enhance security:
// the command line version of beauticoq will be disabled,
// potential access to all local files will be completely impossible.
define('BEAUTICOQ_ALLOW_CMDLINE', true);

//----------------------------------------------------------------------------

function beauticoq_style()
{
   return <<<EOF
.tactic       { color: #D00000; }
.command      { color: #0000FF; }
.define_lemma { color: #0000E0; font-weight: bold; }
.use_lemma    { /*color: #000000; font-weight: bold;*/ }
.body_lemma   { font-weight: bold; }
.comments     { color: #009000; font-weight: normal; }
pre.coq { float: left; padding: 10px; border: 1px solid black; }
.clear { clear: both; }
EOF;
}

//----------------------------------------------------------------------------

define('meta_charset', '<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />');
define('doctype', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">');

//----------------------------------------------------------------------------

function beauticoq_keywords_lists()
{
   return array(
   'command' => 'Sumbool Add Admitted All Arguments Arith AutoInline Axiom Canonical Chapter Check Classes CoFixpoint CoInductive Coercion Coercions Conjectures Constant Constructors Declare Defined Definition Dependent Derive End Eval Export Extern Extract Extraction Fact Field Fixpoint Focus Global Goal Grammar Graph Hint HintDb Hypothesis Hyps_limit Identity If Immediate Implicit Implicits Import Inductive Infix Inline Inspect Intro Intros Inversion Inversion_clear Language Lemma Let Library Load LoadPath Local Locate Ltac ML Module Modules Morphism Mutual NoInline Notation Omega Opaque Open Optimize Parameter Path Paths Print Printing Programs Proof Pwd Qed Read Rec Record Recursive Remark Remove Require Reserved Reset Resolve Restore Rewrite Save Scheme Scope Scopes Script Search SearchAbout SearchPattern SearchRewrite Section Set Setoid Show Silent State Strict Structure Syntactic Syntax Synth Table Tables Tactic Term Test Theorem Time Transparent Tree Type Undo Unfocus Unfold Unset Variable Variables Verbose Visibility Wildcard Write',
   //'tactic' => 'abstract absurd after apply as assert assumption auto autorewrite binding list case cbv change clear clearbody compare compute congruence constructor contradiction conversion tactics cut cutrewrite decide decide equality decompose decompose record decompose sum dependent dependent inversion dependent inversion_clear dependent rewrite derive inversion destruct discrR discriminate discrr do double double induction eapply eauto elim elimtype end equality exact exists fail field first firstorder fold fourier functional generalize generalize dependent hnf idtac in induction info injection intro intro after intro_pattern intros intros pattern intros until intuition inversion inversion_clear inversion_cleardots lapply lazy left lettac match move newdestruct newinduction omega orelse pattern pose print hint progress prolog quote record red refine reflexivity rename repeat replace rewrite right ring set setoid_replace setoid_rewrite simpl simple simple inversion simplify_eq solve split split_Rabs split_Rmult splitabsolu splitrmult stepl stepr struct subst sum symmetry tactic tactic macros tacticals tauto transitivity trivial try unfold until using with',
   );
}

//----------------------------------------------------------------------------

error_reporting(E_ALL);

if (!function_exists('file_put_contents')) // Support for PHP < 5
{
   function file_put_contents($filename, $contents)
   {
      $file = @fopen($filename, 'w');
      if ($file === false)  die("file_put_contents could not write file: $filename");
      fwrite($file, $contents);
      fclose($file);
   }
}

function is_called_from_cmdline()
{
   return !empty($_SERVER['argv']) && !isset($_SERVER['SERVER_ADDR']);
}

//----------------------------------------------------------------------------

class html
{
   function attr_to_str($attr)
   {
      $str = '';
      if (! empty($attr))
         foreach ($attr as $name => $value)
            $str .= ' ' . $name . '="' . htmlspecialchars($value, ENT_QUOTES) . '"';
      return $str;
   }

   function tag($tag, $contents, $attr = array())
   {
      return '<' . $tag . html::attr_to_str($attr) . '>' . $contents . '</' . $tag . '>';
   }

   function span_c($class, $contents)
   {
      return ($class == '') ? $contents : html::tag('span', $contents, array('class' => $class));
   }
}

//----------------------------------------------------------------------------

function beauticoq_keywords()
{
   $keywords = array();
   foreach (beauticoq_keywords_lists() as $kind => $keyword_list)
      foreach (preg_split('/\s/', $keyword_list) as $keyword)
         $keywords[$keyword] = $kind;
   return $keywords;
}

function beauticoq_lexing($matching, $contents)
{
   return preg_split($matching, $contents,
      -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
}

function beauticoq_step(&$keywords, $contents)
{
   $after_lemma = false;
   $body_lemma  = false;
   $phrases = beauticoq_lexing('/(\(\*|\*\))/', $contents);
   $output = '';
   while (list(, $phrase) = each($phrases))
   {
      if ($phrase == '(*')
      {
         $comments_depth = 1;
         $contents = $phrase;
         while (list(, $phrase) = each($phrases))
         {
            $contents .= $phrase;
            if ($phrase == '(*')
               $comments_depth++;
            else if ($phrase == '*)')
               $comments_depth--;
            if ($comments_depth == 0)
               break;
         }
         $output .= html::span_c('comments', htmlspecialchars($contents));
      }
      else
      {
         foreach (beauticoq_lexing('/(\.|@|�|\(|[\[\];\(\)\.]|\s)/', $phrase) as $word)
         {
            $class = '';

            if ($word == '.')
               $body_lemma = false;
            if ($body_lemma)
               $class = 'body_lemma';
            else if ($word == 'Lemma' || $word == 'Theorem')
            {
               $after_lemma = true;
               $class = 'define_lemma';
            }
            else if ($after_lemma && preg_match('/\s/', $word) == 0)
            {
               $keywords[$word] = 'use_lemma';
               $after_lemma = false;
               $body_lemma = true;
               $class = 'define_lemma';
            }
            else if (array_key_exists($word, $keywords))
               $class = $keywords[$word];

            $output .= html::span_c($class, htmlspecialchars($word));
         }
      }
   }
   return $output;
}

//----------------------------------------------------------------------------

function beauticoq($sources)
{
   $keywords = beauticoq_keywords();
   $colorized = array();
   foreach ($sources as $source)
      $colorized[] = beauticoq_step($keywords, $source);
   return $colorized;
}

//----------------------------------------------------------------------------

function beauticoq_xhtml($output, $cssdata = false)
{
   if ($cssdata === '')
      $cssdata = beauticoq_style();
   if ($cssdata === false)
      $style = '';
   else
      $style = html::tag('style', $cssdata, array('type' => 'text/css'));
   $contents = html::tag('div', html::tag('pre', $output, array('class' => 'coq')));
   return $style . $contents;
}

function beauticoq_xhtml_area($source, $cssdata = false)
{
   $keywords = beauticoq_keywords();
   return beauticoq_xhtml(beauticoq_step($keywords, $source), $cssdata) .
      '<span class="clear"></span>';
}

//----------------------------------------------------------------------------

function beauticoq_xhtml_page($sources, $titles, $cssdata = '')
{
   $outputs = beauticoq($sources);
   $pages = array();
   foreach ($outputs as $i => $output)
   {
      $head = html::tag('title', htmlspecialchars($titles[$i])) . meta_charset;
      $body = beauticoq_xhtml($output, $cssdata);
      $contents = html::tag('html', html::tag('head', $head) .html::tag('body', $body) );
      $pages[] = doctype . $contents;
   }
   return $pages;
}

function beauticoq_xhtml_page_one($source, $title, $cssdata = '')
{
   $outputs = beauticoq_xhtml_page(array($source), array($title), $cssdata);
   return $outputs[0];
}

//----------------------------------------------------------------------------

function beauticoq_web($filename, $cssdata = '')
{
   ini_set('open_base_dir', BEAUTICOQ_WEB_ROOT_DIRECTORY);
   $source = @file_get_contents($filename);
   if ($source == false)  die("file not found: $filename");
   return beauticoq_xhtml_page_one($source, $filename, $cssdata);
}

//----------------------------------------------------------------------------

function beauticoq_usage()
{
   return <<<EOF
usage:
    php beauticoq.php mysource.v
    php beauticoq.php -css mystyle.css -out myoutdir mysource1.v mysource2.v
EOF;
}

//----------------------------------------------------------------------------

function beauticoq_cmdline($args)
{
   $cssdata = '';
   $dirout = '';
   $filenames = array();
   $sources = array();
   $quiet = false;

   array_shift($args);
   while (list(, $arg) = each($args))
   {
      if ($arg == '-css')
      {
         list(, $cssfile) = each($args);
         $css = @file_get_contents($cssfile);
         if ($css == false)  die("file not found: $arg");
         $cssdata .= "\n".$css;
      }
      else if ($arg == '-out')
         list(, $dirout) = each($args);
      else if ($arg == '-quiet')
         $quiet = true;
      else
      {
         $source = @file_get_contents($arg);
         if ($source == false)  die("file not found: $arg");
         $sources[] = $source;
         $filenames[] = $arg;
      }
   }

   if (empty($sources))  die(beauticoq_usage());
   if (empty($cssdata))  $cssdata = beauticoq_style();
   if (empty($dirout))   $dirout = '.';

   $pages = beauticoq_xhtml_page($sources, $filenames, $cssdata);

   foreach ($filenames as $i => $filename)
   {
      $filename = preg_replace("/(.*)[.]v/i", "\\1", $filename);
      $outfilename = $dirout . '/' . $filename . '.html';
      file_put_contents($outfilename, $pages[$i]);
      if (! $quiet) echo "generated $outfilename\n";
   }
}

//----------------------------------------------------------------------------

if (isset($_GET['beauticoq']))
   echo beauticoq_web($_GET['beauticoq'] . '.v');
else if (BEAUTICOQ_ALLOW_CMDLINE && is_called_from_cmdline())
{
   beauticoq_cmdline($_SERVER['argv']);
   exit;
}

//----------------------------------------------------------------------------

?>