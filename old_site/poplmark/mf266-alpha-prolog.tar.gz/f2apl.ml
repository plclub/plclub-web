let _ =
   try
     let args = Sys.argv in
     let _ = if Array.length args < 2 then (print_string "Please give term as command line argument"; print_newline(); flush stdout) else
                if Array.length args > 2 then (print_string "Please give only one term as a command line argument"; print_newline(); flush stdout) else () in
     let tm = Array.get args 1 in
     let lexbuf = Lexing.from_string tm in
           let result = Parser.main Lexer.token lexbuf in
           print_newline(); print_string result; print_newline(); flush stdout;
   with parse_error -> print_string "Syntax Error"; exit 0
