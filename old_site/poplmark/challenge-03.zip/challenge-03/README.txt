1. In typecheck.poplmark there are type checking tests:

        test "testname" = tyctxt |- term : type
        output : bool

   where tyctxt is

        {}                    empty context
        {x : ty, ...}         var binding
        {a <: ty, ...}        tyvar binding

2. In eval.poplmark there are evaluation tests:

        test "testname" = term --->* term
        output : bool

3. In step.poplmark there are reduction step tests:

        test "testname" = term ---> term
        output : bool

        test "testname" = term ---> ?
        output : term

The evaluation tests are of increasing size, starting at fact(2) and the
finishing at fact(9), to give some idea of performance.  There are also some
type checking and step tests where the output is false.

The idea is that someone attempting challenge 3 will take these tests and
run them in their formalization, preferably by parsing the test to give the
appropriate query.
